import { useState } from "react";
import { supabase } from "@/lib/supabase";
import { Todo } from "@/types";

export function useTodoLogic(session: any, triggerHaptic: () => void) {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [isAddingTask, setIsAddingTask] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [newTaskProject, setNewTaskProject] = useState("");
  const [newTaskDueDate, setNewTaskDueDate] = useState("");
  
  const [isTaskEditModalOpen, setIsTaskEditModalOpen] = useState(false);
  const [editingTaskId, setEditingTaskId] = useState<number | null>(null);
  const [editTaskTitle, setEditTaskTitle] = useState("");
  const [editTaskProject, setEditTaskProject] = useState("");

  const handleAddTask = async (e: React.FormEvent) => { 
    e.preventDefault(); 
    if (!newTaskTitle.trim() || !session?.user?.email) return; 
    const { data, error } = await supabase.from('todos').insert({ 
      title: newTaskTitle, 
      project: newTaskProject || "一般タスク", 
      due_date: newTaskDueDate || null, 
      user_email: session.user.email 
    }).select().single(); 
    
    if (!error && data) {
      setTodos([...todos, data as Todo]); 
    }
    setNewTaskTitle(""); setNewTaskProject(""); setNewTaskDueDate(""); setIsAddingTask(false); 
    triggerHaptic();
  };

  const openTaskEditModal = (todo: Todo) => { 
    setEditingTaskId(todo.id); 
    setEditTaskTitle(todo.title); 
    setEditTaskProject(todo.project || ""); 
    setIsTaskEditModalOpen(true); 
    triggerHaptic(); 
  };

  const handleUpdateTask = async () => { 
    if (!editingTaskId || !editTaskTitle.trim()) return; 
    const { data, error } = await supabase.from('todos').update({ 
      title: editTaskTitle, 
      project: editTaskProject || "一般タスク" 
    }).eq('id', editingTaskId).select().single(); 
    
    if (!error && data) { 
      setTodos(todos.map(t => t.id === editingTaskId ? data as Todo : t)); 
      setIsTaskEditModalOpen(false); 
      setEditingTaskId(null); 
      triggerHaptic(); 
    } 
  };

  const handleInlineUpdateTask = async (taskId: number, title: string, project: string, dueDate: string) => { 
    const { data, error } = await supabase.from('todos').update({ 
      title, 
      project: project || "一般タスク", 
      due_date: dueDate || null 
    }).eq('id', taskId).select().single(); 
    
    if (!error && data) setTodos(todos.map(t => t.id === taskId ? data as Todo : t)); 
  };

  const handleDeleteTask = async (taskId: number, e: React.MouseEvent) => { 
    e.stopPropagation(); 
    const { error } = await supabase.from('todos').delete().eq('id', taskId); 
    if (!error) { 
      setTodos(todos.filter(t => t.id !== taskId)); 
      triggerHaptic(); 
    } 
  };

  const handleToggleTodo = async (taskId: number, currentStatus: boolean, e: React.MouseEvent) => { 
    e.stopPropagation(); 
    const { data, error } = await supabase.from('todos').update({ 
      is_completed: !currentStatus 
    }).eq('id', taskId).select().single(); 
    
    if (!error && data) { 
      setTodos(todos.map(t => t.id === taskId ? data as Todo : t)); 
      triggerHaptic(); 
    } 
  };

  return {
    todos, setTodos,
    isAddingTask, setIsAddingTask,
    newTaskTitle, setNewTaskTitle,
    newTaskProject, setNewTaskProject,
    newTaskDueDate, setNewTaskDueDate,
    isTaskEditModalOpen, setIsTaskEditModalOpen,
    editingTaskId, setEditingTaskId,
    editTaskTitle, setEditTaskTitle,
    editTaskProject, setEditTaskProject,
    handleAddTask, openTaskEditModal, handleUpdateTask,
    handleInlineUpdateTask, handleDeleteTask, handleToggleTodo
  };
}