import { useState, useEffect, useMemo } from "react";
import { useSession, signIn, signOut } from "next-auth/react";
import { supabase } from "@/lib/supabase";
import { Group, Todo } from "@/types";
import { useTodoLogic } from "./useTodoLogic";
import { useEventLogic, getDayIndex, formatLocalISO, GOOGLE_COLORS } from "./useEventLogic";
import toast from "react-hot-toast";
import { DEFAULT_HOUR_HEIGHT } from "@/constants/calendar";

export function useCalendarLogic() {
  const { data: session, status } = useSession();

  const [isHapticsEnabled, setIsHapticsEnabled] = useState(true);
  const [syncMonths, setSyncMonths] = useState<number>(3); 

  useEffect(() => {
    if (typeof window !== "undefined") {
      const storedHaptics = localStorage.getItem("mincale_haptics");
      if (storedHaptics !== null) setIsHapticsEnabled(storedHaptics === "true");
      const storedSyncMonths = localStorage.getItem("mincale_sync_months");
      if (storedSyncMonths !== null) setSyncMonths(Number(storedSyncMonths));
    }
    if (typeof window !== "undefined" && window.innerWidth >= 768) { 
      setIsSidebarOpen(true); setIsRightPanelOpen(true); 
    } 
  }, []);

  const triggerHaptic = () => {
    if (isHapticsEnabled && typeof window !== 'undefined' && window.navigator && window.navigator.vibrate) window.navigator.vibrate(15);
  };

  const toggleHaptics = (enabled: boolean) => {
    setIsHapticsEnabled(enabled);
    if (typeof window !== "undefined") {
      localStorage.setItem("mincale_haptics", String(enabled));
      if (enabled && window.navigator && window.navigator.vibrate) window.navigator.vibrate(15);
    }
  };

  const handleSyncMonthsChange = (val: number) => {
    setSyncMonths(val);
    if (typeof window !== "undefined") localStorage.setItem("mincale_sync_months", String(val));
    toast.success("同期期間を変更しました。次回読み込み時から適用されます。"); triggerHaptic();
  };

  const todoLogic = useTodoLogic(session, triggerHaptic);

  const [viewMode, setViewMode] = useState<"day" | "week" | "month">("week");
  const [activeTab, setActiveTab] = useState<"todo" | "settings">("todo");
  const [groups, setGroups] = useState<Group[]>([]); 

  const [bookingTitle, setBookingTitle] = useState("ミーティングの予約");
  const [bookingDuration, setBookingDuration] = useState(30); 
  const [bookingStartHour, setBookingStartHour] = useState(10); 
  const [bookingEndHour, setBookingEndHour] = useState(18); 
  const [bookingDays, setBookingDays] = useState<number[]>([1, 2, 3, 4, 5]); 
  const [bookingLeadTime, setBookingLeadTime] = useState(24); 
  const [weekStartDay, setWeekStartDay] = useState(0);

  const [isSidebarOpen, setIsSidebarOpen] = useState(false); 
  const [isRightPanelOpen, setIsRightPanelOpen] = useState(false); 
  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false); 
  const [isGroupModalOpen, setIsGroupModalOpen] = useState(false); 
  const [newGroupName, setNewGroupName] = useState(""); 
  const [newGroupMemberIds, setNewGroupMemberIds] = useState<string[]>([]);
  const [editingGroupId, setEditingGroupId] = useState<string | null>(null);

  const [isCopied, setIsCopied] = useState(false); 
  const [isLoadingData, setIsLoadingData] = useState(true);
  const [currentViewDate, setCurrentViewDate] = useState(new Date()); 
  const [currentMonthYear, setCurrentMonthYear] = useState("");
  const [accentColor, setAccentColor] = useState("#2563eb"); 
  const [hourHeight, setHourHeight] = useState(DEFAULT_HOUR_HEIGHT);
  const [profileId, setProfileId] = useState<string>("");

  const { days, months, timeMin, timeMax } = useMemo(() => {
    const today = new Date(); const tempDays: any[] = []; const tempMonths: any[] = [];
    const fetchStart = new Date(today.getFullYear(), today.getMonth() - syncMonths, 1); 
    const fetchEnd = new Date(today.getFullYear(), today.getMonth() + syncMonths + 1, 0, 23, 59, 59);
    const startDay = new Date(today); startDay.setDate(today.getDate() - (syncMonths * 30)); let dayOffset = startDay.getDay() - weekStartDay; if (dayOffset < 0) dayOffset += 7; startDay.setDate(startDay.getDate() - dayOffset);
    for (let i = 0; i < (syncMonths * 2 + 1) * 31; i++) { const current = new Date(startDay); current.setDate(startDay.getDate() + i); tempDays.push({ dayIndex: getDayIndex(current), label: current.getDate().toString(), isToday: getDayIndex(current) === getDayIndex(today), date: current }); }
    for (let i = -syncMonths; i <= syncMonths; i++) { const d = new Date(today.getFullYear(), today.getMonth() + i, 1); tempMonths.push({ year: d.getFullYear(), month: d.getMonth(), monthIndex: d.getFullYear() * 100 + d.getMonth(), date: d }); }
    return { days: tempDays, months: tempMonths, timeMin: fetchStart.toISOString(), timeMax: fetchEnd.toISOString() };
  }, [weekStartDay, syncMonths]); 

  const hours = Array.from({ length: 24 }, (_, i) => `${i.toString().padStart(2, '0')}:00`);
  useEffect(() => { setCurrentMonthYear(`${currentViewDate.getFullYear()}年 ${currentViewDate.getMonth() + 1}月`); }, [currentViewDate]);

  const eventLogic = useEventLogic(session, status, triggerHaptic, timeMin, timeMax, accentColor);

  useEffect(() => {
    const fetchData = async () => {
      if (!session?.user?.email) { setIsLoadingData(false); return; }
      setIsLoadingData(true);
      try {
        const { data: todosData } = await supabase.from('todos').select('*').eq('user_email', session.user.email).order('id', { ascending: true }); 
        if (todosData) todoLogic.setTodos(todosData as Todo[]); 
        const { data: groupsData } = await supabase.from('groups').select('*').eq('user_email', session.user.email).order('id', { ascending: true }); 
        if (groupsData) setGroups(groupsData.map(g => ({ id: g.id.toString(), name: g.name, memberIds: g.member_ids })));
        const { data: profileData } = await supabase.from('profiles').select('*').eq('email', session.user.email).single();
        if (profileData) {
          setProfileId(profileData.id || profileData.email); 
          if (profileData.booking_title) setBookingTitle(profileData.booking_title);
          if (profileData.booking_duration) setBookingDuration(profileData.booking_duration); 
          if (profileData.booking_start_hour != null) setBookingStartHour(profileData.booking_start_hour); 
          if (profileData.booking_end_hour != null) setBookingEndHour(profileData.booking_end_hour); 
          if (profileData.booking_days) setBookingDays(profileData.booking_days); 
          if (profileData.booking_lead_time != null) setBookingLeadTime(profileData.booking_lead_time); 
          if (profileData.week_start_day != null) setWeekStartDay(profileData.week_start_day);
        }
      } catch (error) { console.error(error); } finally { setIsLoadingData(false); }
    }; fetchData();
  }, [session]);

  const handleSaveBookingSettings = async () => {
    if (!session?.user?.email) return;
    const { error } = await supabase.from('profiles').update({ booking_title: bookingTitle, booking_duration: bookingDuration, booking_start_hour: bookingStartHour, booking_end_hour: bookingEndHour, booking_days: bookingDays, booking_lead_time: bookingLeadTime, week_start_day: weekStartDay }).eq('email', session.user.email);
    if (!error) { toast.success("設定を保存しました！"); triggerHaptic(); } else { toast.error("設定の保存に失敗しました"); }
  };

  const handleCreateGroupClick = () => { setEditingGroupId(null); setNewGroupName(""); setNewGroupMemberIds([]); setIsGroupModalOpen(true); triggerHaptic(); };
  const handleEditGroupClick = (group: Group, e: React.MouseEvent) => { e.stopPropagation(); setEditingGroupId(group.id); setNewGroupName(group.name); setNewGroupMemberIds(group.memberIds); setIsGroupModalOpen(true); triggerHaptic(); };
  const handleCloseGroupModal = () => { setIsGroupModalOpen(false); setEditingGroupId(null); setNewGroupName(""); setNewGroupMemberIds([]); };
  const handleSaveGroup = async () => { 
    if (!newGroupName.trim() || newGroupMemberIds.length === 0 || !session?.user?.email) return; 
    if (editingGroupId) {
      const { data, error } = await supabase.from('groups').update({ name: newGroupName, member_ids: newGroupMemberIds }).eq('id', parseInt(editingGroupId, 10)).select().single();
      if (!error && data) { setGroups(groups.map(g => g.id === editingGroupId ? { id: data.id.toString(), name: data.name, memberIds: data.member_ids } : g)); triggerHaptic(); toast.success("グループを更新しました"); }
    } else {
      const { data, error } = await supabase.from('groups').insert({ name: newGroupName, member_ids: newGroupMemberIds, user_email: session.user.email }).select().single(); 
      if (!error && data) { setGroups([...groups, { id: data.id.toString(), name: data.name, memberIds: data.member_ids }]); triggerHaptic(); toast.success("グループを作成しました"); } 
    }
    handleCloseGroupModal();
  };
  const handleDeleteGroup = async (groupId: string, e: React.MouseEvent) => { e.stopPropagation(); const { error } = await supabase.from('groups').delete().eq('id', parseInt(groupId, 10)); if (!error) { setGroups(groups.filter(g => g.id !== groupId)); triggerHaptic(); toast.success("グループを削除しました"); } };

  const handleDragStart = (e: React.DragEvent<HTMLDivElement>, todoId: number) => { 
    e.dataTransfer.setData("type", "todo"); e.dataTransfer.setData("todoId", todoId.toString()); 
    if (window.innerWidth < 768) setIsRightPanelOpen(false); triggerHaptic(); 
  };
  const handleEventDragStart = (e: React.DragEvent<HTMLDivElement>, eventId: string, isGoogle: boolean, memberId: string) => { 
    e.dataTransfer.setData("type", "event"); e.dataTransfer.setData("eventId", eventId); e.dataTransfer.setData("isGoogle", isGoogle.toString()); e.dataTransfer.setData("memberId", memberId); triggerHaptic(); 
  };
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => e.preventDefault();
  
  const handleDrop = async (e: React.DragEvent<HTMLDivElement>, dayIndex: number, startHour: number) => {
    e.preventDefault(); const dragType = e.dataTransfer.getData("type"); triggerHaptic(); 

    if (dragType === "todo") {
      const draggedTodoId = parseInt(e.dataTransfer.getData("todoId"), 10); 
      const targetTodo = todoLogic.todos.find((t) => t.id === draggedTodoId); 
      const targetCalendarId = eventLogic.newEventMemberId || eventLogic.members[0]?.id || "";
      if (targetTodo && targetCalendarId) {
        const token = (session as any)?.accessToken; if (!token) return;
        const h = Math.floor(startHour); const m = Math.round((startHour % 1) * 60); const y = Math.floor(dayIndex / 10000); const mo = Math.floor((dayIndex % 10000) / 100) - 1; const d = dayIndex % 100;
        const startDt = new Date(y, mo, d); startDt.setHours(h, m, 0, 0); const endDt = new Date(startDt.getTime() + 1 * 60 * 60 * 1000); 
        try {
          const res = await fetch(`https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(targetCalendarId)}/events`, { method: 'POST', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ summary: targetTodo.title, start: { dateTime: formatLocalISO(startDt) }, end: { dateTime: formatLocalISO(endDt) } }) });
          if (!res.ok) throw new Error("Google作成エラー"); const createdEvent = await res.json();
          await supabase.from('todos').delete().eq('id', draggedTodoId);
          eventLogic.setEvents((prev) => [...prev, { id: createdEvent.id, memberId: targetCalendarId, title: targetTodo.title, dayIndex: dayIndex, startHour: startHour, duration: 1, isGoogle: true, colorHex: createdEvent.colorId ? GOOGLE_COLORS[createdEvent.colorId] : null, colorId: createdEvent.colorId || "", recurrence: createdEvent.recurrence ? createdEvent.recurrence[0] : "none", location: "", description: "" }]); 
          todoLogic.setTodos((prev) => prev.filter((t) => t.id !== draggedTodoId)); 
          if (!eventLogic.selectedMemberIds.includes(targetCalendarId)) eventLogic.setSelectedMemberIds((prev) => [...prev, targetCalendarId]);
          toast.success("タスクを予定に変換しました"); 
        } catch(e) { toast.error("予定の作成に失敗しました"); } 
      }
    } else if (dragType === "event") {
      const eventId = e.dataTransfer.getData("eventId"); const memberId = e.dataTransfer.getData("memberId"); const targetEvent = eventLogic.events.find(ev => ev.id === eventId); if (!targetEvent) return;
      const h = Math.floor(startHour); const m = Math.round((startHour % 1) * 60); const y = Math.floor(dayIndex / 10000); const mo = Math.floor((dayIndex % 10000) / 100) - 1; const d = dayIndex % 100;
      const startDt = new Date(y, mo, d); startDt.setHours(h, m, 0, 0); const endDt = new Date(startDt.getTime() + targetEvent.duration * 60 * 60 * 1000); 
      
      eventLogic.setEvents(prev => prev.map(ev => ev.id === eventId ? { ...ev, dayIndex, startHour } : ev));

      const token = (session as any)?.accessToken; if (!token) return;
      try {
        const res = await fetch(`https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(memberId)}/events/${encodeURIComponent(eventId)}`, { method: 'PATCH', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ start: { dateTime: formatLocalISO(startDt) }, end: { dateTime: formatLocalISO(endDt) } }) });
        if (!res.ok) throw new Error("Google更新エラー"); 
      } catch (error: any) { toast.error("予定の移動に失敗しました"); } 
    }
  };

  const getCommonFreeTimeText = () => {
    const freeSlots: string[] = []; const now = new Date(); const minBookingTime = new Date(now.getTime() + bookingLeadTime * 60 * 60 * 1000);
    const visibleDays = days.filter(d => d.dayIndex >= getDayIndex(now) && bookingDays.includes(d.date.getDay()));
    let addedDaysCount = 0;
    
    for (let d = 0; d < visibleDays.length; d++) {
      if (addedDaysCount >= 5) break; 
      const dt = visibleDays[d].date; const dateStr = `${dt.getMonth()+1}/${dt.getDate()}(${['日','月','火','水','木','金','土'][dt.getDay()]})`;
      let currentMin = bookingStartHour * 60; const endMin = bookingEndHour * 60;
      let dayFreeBlocks = []; let currentBlockStart = -1; let currentBlockEnd = -1;

      while (currentMin < endMin) {
        if (currentMin + bookingDuration > endMin) break;
        const h = Math.floor(currentMin / 60); const m = currentMin % 60; const slotStart = new Date(dt.getFullYear(), dt.getMonth(), dt.getDate(), h, m, 0);
        let isOccupied = false;
        
        if (slotStart <= minBookingTime) { isOccupied = true; } else {
          for (const event of eventLogic.events) { 
            if (eventLogic.selectedMemberIds.includes(event.memberId) && event.dayIndex === visibleDays[d].dayIndex) { 
               const evStartH = event.startHour; const evEndH = event.startHour + event.duration;
               const slotStartH = currentMin / 60; const slotEndH = (currentMin + bookingDuration) / 60;
               if (slotStartH < evEndH && slotEndH > evStartH) { isOccupied = true; break; }
            } 
          }
        }
        if (!isOccupied) {
          if (currentBlockStart === -1) { currentBlockStart = currentMin; currentBlockEnd = currentMin + bookingDuration; } else { currentBlockEnd = currentMin + bookingDuration; }
        } else {
          if (currentBlockStart !== -1) {
            const sH = Math.floor(currentBlockStart / 60).toString().padStart(2, '0'); const sM = (currentBlockStart % 60).toString().padStart(2, '0');
            const eH = Math.floor(currentBlockEnd / 60).toString().padStart(2, '0'); const eM = (currentBlockEnd % 60).toString().padStart(2, '0');
            dayFreeBlocks.push(`${sH}:${sM}〜${eH}:${eM}`); currentBlockStart = -1;
          }
        }
        currentMin += bookingDuration;
      }
      if (currentBlockStart !== -1) {
        const sH = Math.floor(currentBlockStart / 60).toString().padStart(2, '0'); const sM = (currentBlockStart % 60).toString().padStart(2, '0');
        const eH = Math.floor(currentBlockEnd / 60).toString().padStart(2, '0'); const eM = (currentBlockEnd % 60).toString().padStart(2, '0');
        dayFreeBlocks.push(`${sH}:${sM}〜${eH}:${eM}`);
      }
      if (dayFreeBlocks.length > 0) { freeSlots.push(`・${dateStr} ${dayFreeBlocks.join(', ')}`); addedDaysCount++; }
    }
    if (freeSlots.length === 0) { freeSlots.push("※現在ご提示できる直近の空き日程がありません。恐れ入りますがリンクからカレンダーをご確認ください。"); }
    const userSlug = session?.user?.email ? session.user.email.split('@')[0] : profileId;
    const bookingUrl = typeof window !== 'undefined' ? `${window.location.origin}/t/${userSlug}` : `https://mincale.app/t/${userSlug}`;
    
    return `お世話になっております。\n次回のお打ち合わせにつきまして、以下の日程でご都合のよろしい日時はございますでしょうか？\n\n${freeSlots.join("\n")}\n\n▼ こちらの専用リンクから、ご都合の良い時間を直接ご予約いただけます：\n${bookingUrl}\n\nご検討のほど、よろしくお願いいたします。`;
  };

  const handleCopyToClipboard = async (textToCopy?: string) => { 
    try { await navigator.clipboard.writeText(textToCopy !== undefined ? textToCopy : getCommonFreeTimeText()); setIsCopied(true); triggerHaptic(); setTimeout(() => setIsCopied(false), 2000); toast.success("クリップボードにコピーしました"); } 
    catch (err) { toast.error("コピーに失敗しました"); } 
  };

  return {
    session, status, signIn, signOut, viewMode, setViewMode, activeTab, setActiveTab,
    groups, setGroups,
    isSidebarOpen, setIsSidebarOpen, isRightPanelOpen, setIsRightPanelOpen,
    isScheduleModalOpen, setIsScheduleModalOpen,
    isGroupModalOpen, setIsGroupModalOpen,
    newGroupName, setNewGroupName, newGroupMemberIds, setNewGroupMemberIds,
    isCopied, setIsCopied, isLoadingData, setIsLoadingData,
    currentMonthYear, setCurrentMonthYear,
    accentColor, setAccentColor, hourHeight, setHourHeight,
    bookingTitle, setBookingTitle,
    bookingDuration, setBookingDuration, bookingStartHour, setBookingStartHour, bookingEndHour, setBookingEndHour, bookingDays, setBookingDays, bookingLeadTime, setBookingLeadTime, weekStartDay, setWeekStartDay, handleSaveBookingSettings,
    days, months, todayDate: new Date().getDate(), hours,
    isHapticsEnabled, toggleHaptics,
    syncMonths, handleSyncMonthsChange,
    handleToday: () => {}, handlePrevWeek: () => {}, handleNextWeek: () => {},
    handleCreateGroupClick, handleEditGroupClick, handleCloseGroupModal, handleSaveGroup, handleDeleteGroup,
    handleDragStart, handleEventDragStart, handleDragOver, handleDrop, getCommonFreeTimeText, handleCopyToClipboard,
    ...todoLogic, 
    ...eventLogic
  };
}